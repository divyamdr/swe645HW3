package com.HW3.student.Controller;
import java.util.List;

import com.HW3.student.Service.studentservice;
import com.HW3.student.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@RestController
@RequestMapping("/api")
public class studentcontroller {
	@Autowired
    studentservice stuService;
	
	@RequestMapping(value="/student", method=RequestMethod.POST)
	public student createEmployee(@RequestBody student stu) {
	    return stuService.createstudent(stu);
	}
	
	@RequestMapping(value="/student", method=RequestMethod.GET)
	public List<student> readstudent() {
	    return stuService.getstudents();
	}
	
	@RequestMapping(value="/", method=RequestMethod.GET)
	public String survey(){
		System.out.println("Hi");
		return "index.html";	
	}
	
	

	}

